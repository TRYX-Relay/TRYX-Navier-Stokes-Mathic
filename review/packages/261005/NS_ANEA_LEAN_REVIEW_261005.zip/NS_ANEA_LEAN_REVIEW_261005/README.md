# NS ANEA Lean reviewer package

Lean review subset of MATHIC v7.2, assembled 5 October 2026.
Source repository: TRYX-Relay/TRYX-Navier-Stokes-Mathic
Source commit: 83d49fca13918bec9baf1a612ac43a114e0e60f1

## Review route

1. [Canonical score](review/Mathic/Navier_Stokes_Mathic_v7_2.PAPER_SYNC.LOCKED.md)
2. [Lean build instructions](verification/ns-mathic-v72/README.md)
3. [Historical kernel receipt](review/TRYX.NS.MATHIC.V7_2.LEAN.KERNEL.RECEIPT.260913.md)
4. [Provenance](PROVENANCE.md) and [citation](CITATION.cff)

## Included

Complete v7.2 Lean project, dedicated verification workflow, canonical score, historical kernel receipt, citation and provenance. Original source bytes are preserved. SHA256SUMS.json records the package contents.

## Excluded from this package

Historical v6 manuscript, charts, replay package and release records; unrelated general TRYX Lean project and workflows; release-publishing workflow; broad reviewer manifests and closeout records; papers, splash artwork, figures, posters, E6B instruments and production files. These remain in their historical repositories and archives. Historical references in preserved provenance describe the source repository, not additional bundled files.

## Verification scope

All 19 copied files match their source Git blob identities. Local NS imports resolve within the package. Lean and Mathlib must be installed/fetched as described in the project README. The source project has no committed lake-manifest.json; this subset preserves its existing dependency declaration without inventing a lockfile. No new Lean build was run for this packaging change. The receipt records the historical build only. The October 5 paper is a separate publication, not a newly verified Lean target.
